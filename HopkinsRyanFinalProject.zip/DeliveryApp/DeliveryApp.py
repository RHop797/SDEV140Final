'''

This code creates a GUI based application made to schedule deliveries for a company

'''
import tkinter as tk
from tkinter import ttk
import subprocess  # Needed for ability to have a button open txt file

class Tooltip:
# Class to show alternate text for images when hovering mouse over the image
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tooltip = None
        self.widget.bind("<Enter>", self.show_tooltip)
        self.widget.bind("<Leave>", self.hide_tooltip)
    
    def show_tooltip(self, event):
        if self.tooltip:
            return
        x, y, _, _ = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 25
        self.tooltip = tk.Toplevel(self.widget)
        self.tooltip.wm_overrideredirect(True)
        self.tooltip.wm_geometry(f"+{x}+{y}")
        label = tk.Label(self.tooltip, text=self.text, background="lightyellow", relief="solid", borderwidth=1)
        label.pack()
    
    def hide_tooltip(self, event):
        if self.tooltip:
            self.tooltip.destroy()
            self.tooltip = None

class Window:
    # Creating the notebook and tabs
    def __init__(self, master):
        self.master = master
        self.notebook = ttk.Notebook(self.master, width=350, height=325)

        self.frame1 = ttk.Frame(self.notebook)
        self.frame3 = ttk.Frame(self.notebook)

        self.label1 = ttk.Label(self.frame1, text="Schedule Delivery")
        self.label3 = ttk.Label(self.frame3, text="View Delivery Schedule")

        self.label1.grid(row=0, column=0, padx=10, pady=10)
        self.label3.grid(row=0, column=0, padx=10, pady=10)

        # Adding buttons to each frame
        self.button1 = ttk.Button(self.frame1, text="Schedule", command=self.schedule_delivery)
        self.button2 = ttk.Button(self.frame1, text="Exit", command=self.exit)
        self.button3 = ttk.Button(self.frame3, text="View", command=self.view_delivery_schedule)
        self.button4 = ttk.Button(self.frame3, text="Exit", command=self.exit)

        self.button1.grid(row=1, column=0, padx=10, pady=10)
        self.button3.grid(row=1, column=0, padx=10, pady=10)
        
        # Adding image to exit buttons
        self.exit_img = tk.PhotoImage(file="exitbutton.png").subsample(7)  # Resize the image
        self.button2.config(image=self.exit_img, compound=tk.LEFT)
        self.button2.grid(row=1, column=1, padx=10, pady=10)
        Tooltip(self.button2, "Red X")
        
        self.button4.config(image=self.exit_img, compound=tk.LEFT)
        self.button4.grid(row=1, column=1, padx=10, pady=10)
        Tooltip(self.button4, "Red X")

        # Adding image for Schedule Delivery button
        self.check_img = tk.PhotoImage(file="GreenCheckmark.png").subsample(13) # Resize the image
        self.button1.config(image=self.check_img, compound=tk.LEFT)
        self.button1.grid(row=1, column=0, padx=10, pady=10)
        Tooltip(self.button1, "Green Checkmark")

        # Adding image for View button
        self.binoculars_img = tk.PhotoImage(file="binoculars.png").subsample(11) #Resize the image
        self.button3.config(image=self.binoculars_img, compound=tk.LEFT)
        self.button3.grid(row=1, column=0, padx=10, pady=10)
        Tooltip(self.button3, "Black Binoculars")
    
        # Entry widgets for "Schedule Delivery" tab using grid
        self.customer_name_label = ttk.Label(self.frame1, text="Customer Name:")
        self.customer_address_label = ttk.Label(self.frame1, text="Address:")
        self.customer_phone_label = ttk.Label(self.frame1, text="Phone number:")
        self.desired_delivery_label = ttk.Label(self.frame1, text="Desired Delivery Date:")
        self.sku_label = ttk.Label(self.frame1, text="Sku#:")
        self.desc_label = ttk.Label(self.frame1, text="Item Description:")

        self.customer_name_entry = ttk.Entry(self.frame1, width=30, validate="all", validatecommand=(self.master.register(self.validate_name), '%P'), invalidcommand=self.show_name_error)
        self.customer_address_entry = ttk.Entry(self.frame1, width=30, validate="all", validatecommand=(self.master.register(self.validate_address), '%P'), invalidcommand=self.show_address_error)
        self.customer_phone_entry = ttk.Entry(self.frame1, width=30, validate="all", validatecommand=(self.master.register(self.validate_phone), '%P'), invalidcommand=self.show_phone_error)
        self.desired_delivery_entry = ttk.Entry(self.frame1, width=30, validate="all", validatecommand=(self.master.register(self.validate_desired_delivery), '%P'), invalidcommand=self.show_desired_delivery_error)
        self.sku_entry = ttk.Entry(self.frame1, width=30, validate="all", validatecommand=(self.master.register(self.validate_sku), '%P'), invalidcommand=self.show_sku_error)
        self.desc_entry = ttk.Entry(self.frame1, width=30, validate="all", validatecommand=(self.master.register(self.validate_desc), '%P'), invalidcommand=self.show_desc_error)

        # Arranging the labels and entries with grid
        self.customer_name_label.grid(row=2, column=0, padx=10, pady=5, sticky=tk.W)
        self.customer_name_entry.grid(row=2, column=1, padx=10, pady=5)
        self.customer_address_label.grid(row=3, column=0, padx=10, pady=5, sticky=tk.W)
        self.customer_address_entry.grid(row=3, column=1, padx=10, pady=5)
        self.customer_phone_label.grid(row=4, column=0, padx=10, pady=5, sticky=tk.W)
        self.customer_phone_entry.grid(row=4, column=1, padx=10, pady=5)
        self.desired_delivery_label.grid(row=5, column=0, padx=10, pady=5, sticky=tk.W)
        self.desired_delivery_entry.grid(row=5, column=1, padx=10, pady=5)
        self.sku_label.grid(row=6, column=0, padx=10, pady=5, sticky=tk.W)
        self.sku_entry.grid(row=6, column=1, padx=10, pady=5)
        self.desc_label.grid(row=7, column=0, padx=10, pady=5, sticky=tk.W)
        self.desc_entry.grid(row=7, column=1, padx=10, pady=5)

        # Place the clear button in the row below the SKU and description fields
        self.clear_button = ttk.Button(self.frame1, text="Clear Fields", command=self.clear_fields)
        self.clear_button.grid(row=8, column=0, padx=(10, 0), pady=10, columnspan=2)

        self.frame1.grid_rowconfigure(9, weight=1)  # Make sure empty row takes up remaining space

        # Packing frames into notebook using grid
        self.frame1.grid(sticky="nsew", padx=5, pady=5)
        self.frame3.grid(sticky="nsew", padx=5, pady=5)

        self.notebook.add(self.frame1, text="Schedule Delivery")
        self.notebook.add(self.frame3, text="View Delivery Schedule")

        self.notebook.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

        # Label at bottom of window to display error messages
        self.status_label = ttk.Label(self.master, text="")
        self.status_label.grid(row=1, column=0, padx=10, pady=10)

    # Creating validation requirements for each entry
    def validate_name(self, new_text):
        return all(c.isalpha() or c.isspace() for c in new_text) and len(new_text) > 0

    def validate_address(self, new_text):
        return len(new_text) > 0

    def validate_phone(self, new_text):
        return new_text.isdigit() and len(new_text) <= 10

    def validate_desired_delivery(self, new_text):
        return len(new_text) > 0
    
    def validate_sku(self, new_text):
        return new_text.isdigit() and len(new_text) <= 7
    
    def validate_desc(self, new_text):
        return len(new_text) > 0 
    
    # Creating error messages if validation conditions not met. Also displays message in status label as cursor moves between entry boxes.
    def show_name_error(self):
        self.status_label.config(text="Please enter a valid name.")

    def show_address_error(self):
        self.status_label.config(text="Please enter a valid address.")

    def show_phone_error(self):
        self.status_label.config(text="Please enter a valid phone number with area code (10 digits).")

    def show_desired_delivery_error(self):
        self.status_label.config(text="Please enter a desired delivery date mm/dd/yyyy.")

    def show_sku_error(self):
        self.status_label.config(text="Please enter a valid SKU number.")

    def show_desc_error(self):
        self.status_label.config(text="Please enter an item description.")

    # Functionality for exit buttons
    def exit(self):
        self.master.quit()

    # Schedule delivery button gathers information entered from entries and checks validation. Then it writes information to txt file.
    def schedule_delivery(self):
        customer_name = self.customer_name_entry.get()
        customer_address = self.customer_address_entry.get()
        customer_phone = self.customer_phone_entry.get()
        desired_delivery = self.desired_delivery_entry.get()
        sku_number = self.sku_entry.get()
        item_desc = self.desc_entry.get()

        if (self.validate_name(customer_name) and
            self.validate_address(customer_address) and
            self.validate_phone(customer_phone) and
            self.validate_sku(sku_number) and
            self.validate_desc(item_desc) and
            self.validate_desired_delivery(desired_delivery)):

            with open("delivery_schedule.txt", "a") as file:
                file.write(f"Customer Name: {customer_name}\n")
                file.write(f"Address: {customer_address}\n")
                file.write(f"Phone Number: {customer_phone}\n")
                file.write(f"Sku#: {sku_number}\n")
                file.write(f"Item Description: {item_desc}\n")
                file.write(f"Desired Delivery Date: {desired_delivery}\n\n")

            # Update status label
            self.status_label.config(text="Delivery Scheduled!")

            # Clear fields
            self.clear_fields()

        else:
            # Display error message for fields that failed validation
            if not self.validate_name(customer_name):
                self.show_name_error()
            elif not self.validate_address(customer_address):
                self.show_address_error()
            elif not self.validate_phone(customer_phone):
                self.show_phone_error()
            elif not self.validate_sku(sku_number):
                self.show_sku_error()
            elif not self.validate_desc(item_desc):
                self.show_desc_error()
            elif not self.validate_desired_delivery(desired_delivery):
                self.show_desired_delivery_error()

    def clear_fields(self):
        # Temporarily disable validation to clear fields. I had a hard time getting this to work, I found this solution on stack overflow. Not sure if it's the best way but it seems to work. 
        self.customer_name_entry.config(validate="none")
        self.customer_address_entry.config(validate="none")
        self.customer_phone_entry.config(validate="none")
        self.desired_delivery_entry.config(validate="none")
        self.sku_entry.config(validate="none")
        self.desc_entry.config(validate="none")

        # Clear all entry fields
        self.customer_name_entry.delete(0, tk.END)
        self.customer_address_entry.delete(0, tk.END)
        self.customer_phone_entry.delete(0, tk.END)
        self.desired_delivery_entry.delete(0, tk.END)
        self.sku_entry.delete(0, tk.END)
        self.desc_entry.delete(0, tk.END)

        # Re-enable validation
        self.customer_name_entry.config(validate="all", validatecommand=(self.master.register(self.validate_name), '%P'), invalidcommand=self.show_name_error)
        self.customer_address_entry.config(validate="all", validatecommand=(self.master.register(self.validate_address), '%P'), invalidcommand=self.show_address_error)
        self.customer_phone_entry.config(validate="all", validatecommand=(self.master.register(self.validate_phone), '%P'), invalidcommand=self.show_phone_error)
        self.desired_delivery_entry.config(validate="all", validatecommand=(self.master.register(self.validate_desired_delivery), '%P'), invalidcommand=self.show_desired_delivery_error)
        self.sku_entry.config(validate="all", validatecommand=(self.master.register(self.validate_sku), '%P'), invalidcommand=self.show_sku_error)
        self.desc_entry.config(validate="all", validatecommand=(self.master.register(self.validate_desc), '%P'), invalidcommand=self.show_desc_error)

        # Clear status label
        self.status_label.config(text="")

    # Open the txt file to view schedule
    def view_delivery_schedule(self):
        subprocess.Popen(["notepad.exe", "delivery_schedule.txt"])

def main(): # Sets up GUI and starts event loop
    root = tk.Tk() # Creates main window
    root.title("Delivery Scheduler") # Title for main window
    root.geometry("400x400") # Set size of main window
    app = Window(root) # Create instance of 'Window' class
    root.mainloop() # Keeps main window open and functional by starting event loop

# Call main function
if __name__ == "__main__":
    main()

'''Github link https://github.com/RHop797/SDEV140Final'''
